from django.apps import AppConfig


class Config(AppConfig):

    name = 'aether.common'
    verbose_name = 'Aether common module'
