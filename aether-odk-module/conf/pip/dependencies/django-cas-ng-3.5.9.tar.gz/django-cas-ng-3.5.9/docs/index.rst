.. Django CAS NG documentation master file, created by
   sphinx-quickstart on Sat May 24 09:24:34 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Django CAS NG's documentation!
=========================================

Contents:

.. toctree::
   :maxdepth: 2

   changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

