
Install from source::

    python setup install


Create distribution package::

    python setup.py sdist

The distribution package will be generated under dist/


Register new release to pipy::

    python setup.py register


Make a release to pypi::

    python setup.py sdist upload
