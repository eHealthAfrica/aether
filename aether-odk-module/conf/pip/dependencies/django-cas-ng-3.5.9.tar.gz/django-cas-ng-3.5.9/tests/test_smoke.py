from __future__ import absolute_import
from django_cas_ng.models import *
from django_cas_ng.backends import *
from django_cas_ng.middleware import *
from django_cas_ng.views import *
from django_cas_ng.decorators import *

def test_nothing_is_on_fire():
    # Nothing to do here, this file is used for testing import works.
    pass

