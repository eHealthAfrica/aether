======================
Django UMS auth client
======================

This is the client side for integration with the UMS server,
providing single-sign-on with CAS, ``django-cas-ng`` is a dependency.

Quick start
-----------

1. Install the ``django-ums-client``::

    pip install git+https://github.com/eHealthAfrica/django-ums-client.git@v0.2.6


1.1 Or install it packaged as a wheel file, the most recent version is in the ``dist`` directory::

    pip install -f directory_with_wheel django-ums-client


2. Add ``django_cas_ng`` and ``ums_client`` to your ``INSTALLED_APPS`` setting like this::

    INSTALLED_APPS = [
        ...
        'django_cas_ng',
        'ums_client',
    ]


3. Add ``ums_client.backends.UMSRoleBackend`` to your AUTHENTICATION_BACKENDS setting like this::

    AUTHENTICATION_BACKENDS = (
        ...
        'ums_client.backends.UMSRoleBackend',
    )


4. Set the ``CAS_SERVER_URL`` to the server used for authenticating like this::

    CAS_SERVER_URL = 'https://ums-dev.ehealthafrica.org/'

    # Note: It is recommended to get this setting from an environment variable

    CAS_SERVER_URL = os.environ.get('CAS_SERVER_URL', 'https://ums-dev.ehealthafrica.org/')


5. Set the ``HOSTNAME`` to the server this is running on, necessary for the auth callback like this::

    HOSTNAME = 'servername.ehealthafrica.org'

    # Note: It is recommended to get this setting from an environment variable

    HOSTNAME = os.environ.get('HOSTNAME', 'servername.ehealthafrica.org')


6. Set your login and logout views in ``urls.py`` to the ones provided by ``django_cas_ng``::

    import django_cas_ng.views

    ...

    url(r'^accounts/login/$', django_cas_ng.views.login, name='cas_login'),
    url(r'^accounts/logout/$', django_cas_ng.views.logout, name='cas_logout'),


7. Set the used ``CAS_VERSION`` to Version ``3``::

    CAS_VERSION = 3


8. Set the setting ``CAS_LOGOUT_COMPLETELY`` to ``True`` to actually log out with the UMS server::

    CAS_LOGOUT_COMPLETELY = True


9. Run ``python manage.py migrate`` to create the ``ums_client`` and ``django_cas_ng`` database tables.


