from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import Group
from django.conf import settings


class UserRole(models.Model):
    name = models.CharField(max_length=200)
    # the matching group for this role
    group = models.ForeignKey(Group,
                              null=True,
                              blank=True,
                              on_delete=models.CASCADE)
    # the user
    user = models.ForeignKey(settings.AUTH_USER_MODEL,
                             null=True,
                             blank=True,
                             on_delete=models.CASCADE)

    class Meta:
        unique_together = (("user", "group"),)

    def __unicode__(self):
        return "{} - {}".format(self.user.username, self.name)
