from json import loads

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group

from .models import UserRole

from django_cas_ng.signals import (
    cas_user_authenticated, cas_user_logout
)

def set_user_roles(user, roles):
    # remove existing assignments in DB
    UserRole.objects.filter(user=user).delete()

    # create new assignments
    for role_name in roles:
        # try to find matching Group
        user_role = UserRole(name=role_name, user=user)
        try:
            group = Group.objects.get(name__iexact=role_name)   
            user_role.group = group 
        except Group.DoesNotExist:
            print("local Group with name '{}' does not exist".format(role_name))

        user_role.save()



def auth_callback(sender, user=None, attributes=None, **kwargs):
    if user and attributes:
        roles = attributes.get('roles',"") or ""
        set_user_roles(user, roles.split(","))
        # also update first name and last name if empty
        if not user.first_name.strip():
            # update the user object with information given from the response
            user.first_name = attributes.get('first_name')
            user.last_name = attributes.get('last_name')
            user.email = attributes.get('email', "")
            user_img = attributes.get('user_image', "")
            if hasattr(user, "profile") and user.profile:
                # use attached profile object to store additional data if present
                user.profile.profile_picture_url = user_img
                user.profile.display_name = attributes.get('display_name', "")
                user.profile.save()
                
            # do something with user image here ..
            user.save()


def setup_callbacks():
    cas_user_authenticated.connect(auth_callback)
