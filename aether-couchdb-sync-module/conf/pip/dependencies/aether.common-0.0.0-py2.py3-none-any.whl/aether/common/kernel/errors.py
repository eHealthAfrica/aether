class SubmissionError(Exception):
    pass
