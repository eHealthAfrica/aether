class SubmissionError(Exception):
    pass
