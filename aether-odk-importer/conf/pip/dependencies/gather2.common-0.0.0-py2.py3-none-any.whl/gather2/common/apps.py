from django.apps import AppConfig


class Config(AppConfig):

    name = 'gather2.common'
    verbose_name = 'Gather2 common module'
