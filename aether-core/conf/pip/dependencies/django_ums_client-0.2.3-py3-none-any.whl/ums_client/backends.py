from django_cas_ng.backends import CASBackend

# to store the roles on successful callback
from .callbacks import setup_callbacks
setup_callbacks()

class UMSRoleBackend(CASBackend):
    """UMS role to group permission adapter"""

    def get_group_permissions(self, user_obj, obj=None):
        """
        Returns a set of permission strings the user `user_obj` has from the
        groups they belong by role assignment from UMS.
        """

        # the resulting permission set for the roles
        result = set()

        for user_role in user_obj.userrole_set.all():
            if user_role.group:
                for permission in user_role.group.permissions.all():
                    permission_name = u"{1}.{0}".format(*permission.natural_key()[:2])
                    result.add(permission_name)

        return result

    def has_perm(self, user, perm, obj):
        permissions = self.get_group_permissions(user, obj)
        return perm in permissions
