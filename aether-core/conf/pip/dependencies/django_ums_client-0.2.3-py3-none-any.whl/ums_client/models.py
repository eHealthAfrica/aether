from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User, Group


class UserRole(models.Model):
    name = models.CharField(max_length=200)
    # the matching group for this role
    group = models.ForeignKey(Group, null=True, blank=True)
    # the user
    user = models.ForeignKey(User, null=True, blank=True)

    class Meta:
        unique_together = (("user", "group"),)

    def __unicode__(self):
        return "{} - {}".format(self.user.username, self.name)
